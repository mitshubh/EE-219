************** Team members  ************** 
Shubham Mittal (104774903)
Swati Arora (404758379)
Anshita Mehrotra (904743371)

************** Environment Setup ************** 

All codes and .csv files need to be in the same folder.


************** Running the code ************** 
1. The python code files are ans1.py, ans2.py, ans2b.py, ans2c.py, ans3.py, ans3b.py, ans3c.py, ans4a.py, ans4b.py, ans5a.py, ans5b.py

2. Each files contains code of their respective problems. 

3. Select a file and click 'Run' to see solution of any part.