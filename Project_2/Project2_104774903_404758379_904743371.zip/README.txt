************** Team members  ************** 
Shubham Mittal (104774903)
Swati Arora (404758379)
Anshita Mehrotra (904743371)

************** Environment Setup ************** 

All codes need to be in the same folder.


************** Running the code ************** 
1. The python code files are ans-a.py, ans-b.py, ans-c.py, ans-d.py, ans-e.py, ans-f.py, ans-g.py, ans-h_l1.py, ans-h_l2.py, ans-i.py

2. Each files contains code of their respective problems. 

3. Select a file and click 'Run' to see solution of any part.

4. All images are in the Images folder