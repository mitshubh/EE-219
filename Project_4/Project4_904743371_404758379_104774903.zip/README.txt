************** Team members  ************** 
Anshita Mehrotra (904743371)
Swati Arora (404758379)
Shubham Mittal (104774903)
************** Environment Setup ************** 

All codes need to be in the same folder.

************** Running the code ************** 
1. The python code files are ans-a.py, ans-b.py, ans-c.py, ans-d.py, ans-e.py, ans-f.py

2. Each files contains code of their respective problems. 

3. Select a file and click 'Run' to see solution of any part.